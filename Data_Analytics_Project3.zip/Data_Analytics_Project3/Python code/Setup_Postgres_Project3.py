import pandas as pd
from sqlalchemy import create_engine

# 1. Aapka cleaned dataset load karte hain
try:
    df = pd.read_csv("Cleaned_Dataset_Project1.csv")
    print("✅ Cleaned Dataset Loaded Successfully!")
except:
    df = pd.read_excel("Cleaned_Dataset_Project1.xlsx")

# 2. PostgreSQL Engine Connection String banate hain
# Format: postgresql://username:password@localhost:5432/databasename
# AGAR AAPNE NAYA DATABASE NAHI BANAYA TOH DEFAULT DATABASE NAME 'postgres' HI RAKHEIN
USER = 'postgres'
PASSWORD = 'eshawajeeh211125'  # <-- Yahan apna password likhein
HOST = 'localhost'
PORT = '5432'
DB_NAME = 'postgres'  # <-- Agar koi alag DB banaya hai toh uska naam likhein

try:
    engine = create_engine(f'postgresql://{USER}:{PASSWORD}@{HOST}:{PORT}/{DB_NAME}')
    
    # 3. Data ko PostgreSQL Table mein convert/upload karte hain
    df.to_sql("orders_table", engine, if_exists="replace", index=False)
    print("📦 Boom! Aapka data PostgreSQL ki 'orders_table' table mein successfully chala gaya hai.")
except Exception as e:
    print(f"❌ Connection Error: {e}")