import pandas as pd

# File ka naam
excel_file_path = "Dataset for Data Analytics.xlsx"

try:
    print("🔄 Excel file read ho rahi hai...")
    # engine='openpyxl' ke sath read kar rahe hain
    df = pd.read_excel(excel_file_path, engine='openpyxl')
    
    print("📋 Aapke Dataset ke Asli Columns yeh hain:")
    print(list(df.columns))

    # ==========================================
    # PHASE 1: INTEGRITY AUDIT - REMOVE DUPLICATES
    # ==========================================
    # 'OrderID' column se saaray duplicate orders khatam karna
    if 'OrderID' in df.columns:
        df.drop_duplicates(subset=['OrderID'], keep='first', inplace=True)
        print("✅ Duplicates remove ho gaye.")

    # ==========================================
    # PHASE 2: STANDARDIZE DATES (ISO 8601 Format)
    # ==========================================
    # 'Date' column ko YYYY-MM-DD standard format mein convert karna
    if 'Date' in df.columns:
        df['Date'] = pd.to_datetime(df['Date'], errors='coerce').dt.strftime('%Y-%m-%d')
        df['Date'] = df['Date'].ffill() # Khali dates ko fill karna
        print("✅ Dates ISO format (YYYY-MM-DD) par set ho gayin.")

    # ==========================================
    # PHASE 3: NUMERIC PRECISION & IMPUTATION
    # ==========================================
    # UnitPrice aur TotalPrice ko handle karna aur 2 decimal places par round karna
    numeric_cols = ['UnitPrice', 'TotalPrice', 'Quantity']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            median_val = df[col].median()
            df[col] = df[col].fillna(median_val).round(2)
            
    print("✅ Numeric values 2 decimals par standardise ho gayin.")

    # ==========================================
    # MANDATORY CHECKLIST VERIFICATION
    # ==========================================
    duplicate_count = df.duplicated(subset=['OrderID']).sum() if 'OrderID' in df.columns else 0
    missing_dates = df['Date'].isnull().sum() if 'Date' in df.columns else 0

    print("\n--- 📋 DecodeLabs Verification Audit ---")
    print(f"Remaining Duplicate IDs: {duplicate_count} (Should be 0)")
    print(f"Incorrect/Missing Dates: {missing_dates} (Should be 0)")

    # ==========================================
    # SAVE THE FINAL CLEANED FILE
    # ==========================================
    output_file_name = "Cleaned_Dataset_Project1.csv"
    df.to_csv(output_file_name, index=False)
    
    print(f"\n✨ [SUCCESS] Mubarak ho bhai! File ban gayi hai: '{output_file_name}'")

except Exception as e:
    print(f"\n❌ Abhi bhi yeh error hai: {e}")