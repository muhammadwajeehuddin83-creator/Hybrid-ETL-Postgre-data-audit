import pandas as pd
from sqlalchemy import create_engine

# Database Connection Settings (Apna password 'your_postgresql_password' ki jagah likhein)
USER = 'postgres'
PASSWORD = 'eshawajeeh211125'  # <-- Yahan apna password likhein
HOST = 'localhost'
PORT = '5432'
DB_NAME = 'postgres'

# Connection Engine build karte hain
engine = create_engine(f'postgresql://{USER}:{PASSWORD}@{HOST}:{PORT}/{DB_NAME}')

def run_query(title, query):
    print("=" * 60)
    print(f"📊 {title}")
    print("=" * 60)
    try:
        output = pd.read_sql_query(query, engine)
        print(output.to_string(index=False))
    except Exception as e:
        print(f"❌ Query Error: {e}")
    print("\n")

# --- TASK 3.1: BASIC SELECT & FROM ---
run_query(
    "1. SELECT ALL RECORDS (Sample View)",
    'SELECT "OrderID" AS order_id, "Product" AS product, "TotalPrice" AS total_price, "OrderStatus" AS order_status FROM orders_table LIMIT 5;'
)

# --- TASK 3.2: FILTERING WITH WHERE CLAUSE ---
run_query(
    "2. WHERE CLAUSE FILTER (Delivered Orders Only)",
    'SELECT "OrderID" AS order_id, "Product" AS product, "TotalPrice" AS total_price, "OrderStatus" AS order_status FROM orders_table WHERE "OrderStatus" = \'Delivered\' LIMIT 5;'
)

# --- TASK 3.3: SORTING WITH ORDER BY ---
run_query(
    "3. ORDER BY CLAUSE (Highest Revenue Orders)",
    'SELECT "OrderID" AS order_id, "Product" AS product, "TotalPrice" AS total_price FROM orders_table ORDER BY "TotalPrice" DESC LIMIT 5;'
)

# --- TASK 3.4: AGGREGATIONS & GROUP BY ---
run_query(
    "4. GROUP BY & AGGREGATIONS (Product Performance Audit)",
    """
    SELECT 
        "Product" AS product, 
        COUNT("OrderID") AS total_orders, 
        SUM("TotalPrice") AS total_revenue, 
        ROUND(AVG("TotalPrice")::numeric, 2) AS avg_order_value
    FROM orders_table 
    GROUP BY "Product"
    ORDER BY total_revenue DESC;
    """
)

# --- TASK 3.5: OPERATIONAL STATUS BREAKDOWN ---
run_query(
    "5. GROUP BY STATUS (Operational Bottleneck Analysis)",
    """
    SELECT 
        "OrderStatus" AS order_status, 
        COUNT("OrderID") AS order_count,
        SUM("TotalPrice") AS revenue_impact
    FROM orders_table 
    GROUP BY "OrderStatus"
    ORDER BY order_count DESC;
    """
)